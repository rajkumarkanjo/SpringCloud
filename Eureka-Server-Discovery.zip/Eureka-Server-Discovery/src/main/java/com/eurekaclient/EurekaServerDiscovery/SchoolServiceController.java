package com.eurekaclient.EurekaServerDiscovery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class SchoolServiceController {
	
	@Autowired
	RestTemplate resttemplate;
	
	/*@Autowired
	private LoadBalancerClient loadBalancer;*/
	
	//consumer 
	@RequestMapping(value= "/getSchoolDetails/{schoolname}" , method = RequestMethod.GET)
	public String getStudents(@PathVariable String schoolname){
		
		System.out.println("details for school "+ schoolname);
		
		
/*      ServiceInstance serviceInstance=loadBalancer.choose("student-service");
		
		System.out.println(serviceInstance.getUri());
		
		String baseUrl=serviceInstance.getUri().toString();
		
		
		System.out.println("baseUrl============================>"+baseUrl);
		
		baseUrl=baseUrl+"/mySchool";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		try{
		response=restTemplate.exchange(baseUrl,
				HttpMethod.GET, null,String.class);
		}catch (Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println(response.getBody()); */
		
	
		String response = resttemplate.exchange("http://student-service/getStudentDetailsForSchool/{schoolname}", HttpMethod.GET, null, 
				new ParameterizedTypeReference<String>() {}, schoolname).getBody();
		
		System.out.println("Response =================> "+ response );
		
		
		
		System.out.println("Response Received as " + response);
		 
        return "School Name -  " + schoolname + " \n Student Details " + response;
    }
 
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
	
    
}

	

	
	

