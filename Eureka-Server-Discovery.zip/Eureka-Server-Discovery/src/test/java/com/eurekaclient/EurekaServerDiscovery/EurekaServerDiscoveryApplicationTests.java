package com.eurekaclient.EurekaServerDiscovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerDiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
