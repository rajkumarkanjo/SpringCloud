package producer.resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import producer.dto.User;

@RestController
public class ProducerController {

    @GetMapping("/testApi")
    public String testApi()
    {
        return "****ProducerController****";
    }

    @GetMapping("/user")
    public User getUser()
    {
      User user = new User();
      user.setCompany("JCPenney");
      user.setId("101");
      user.setName("TEST");
      user.setSalary(50000);

      return user;
    }

}
