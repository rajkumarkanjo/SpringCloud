package consumer.client;

import consumer.dto.User;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name="user-producer")
public interface UserClient {

    @GetMapping("/testApi")
    public String testApi();

    @GetMapping("/user")
    public User getUser();
}
