package consumer.resource;


import consumer.client.UserClient;
import consumer.dto.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.ws.rs.Produces;
import java.util.ArrayList;
import java.util.List;

@RestController
public class ConsumerController {


    @Autowired
    UserClient userclient;

    @GetMapping(value = "/testApi")
    public void testApiEx()
    {
        System.out.println("TESTING DATA ======="+ userclient.testApi());
    }

    @GetMapping(value = "/user")
   // @Produces(MediaType.APPLICATION_JSON)
    public User getuserdata()
    {
        System.out.println("USER-PRODUCER DATA using Feign Client Call =======> \n USER ID : "+

                userclient.getUser().getId()      +" \n COMPANY NAME : "+
                userclient.getUser().getCompany() +" \n USER NAME : "+
                userclient.getUser().getName()    +" \n USER SALARY : "+
                userclient.getUser().getSalary()
        );

        User userTest = new User();
        userTest.setId(userclient.getUser().getId());
        userTest.setCompany(userclient.getUser().getCompany());
        userTest.setName(userclient.getUser().getName());
        userTest.setSalary(userclient.getUser().getSalary());

        return userTest;


    }


/*    @Autowired
    RestTemplate restTemplate;

    @RequestMapping(value = "/getApi", method = RequestMethod.GET)
    public String getStudents()
    {

        String response = restTemplate.exchange("http://user-producer/getApi",
                HttpMethod.GET, null, new ParameterizedTypeReference<String>() {}).getBody();

        System.out.println("Response Received as " + response);

        return "School Name -  "  + " \n Student Details " + response;
    }

    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }*/
}



