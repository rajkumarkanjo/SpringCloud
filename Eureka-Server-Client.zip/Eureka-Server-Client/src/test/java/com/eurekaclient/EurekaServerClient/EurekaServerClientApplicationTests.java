package com.eurekaclient.EurekaServerClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
