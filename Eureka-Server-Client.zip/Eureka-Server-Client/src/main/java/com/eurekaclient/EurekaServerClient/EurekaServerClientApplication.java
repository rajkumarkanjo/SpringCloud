package com.eurekaclient.EurekaServerClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

//https://howtodoinjava.com/spring-cloud/spring-cloud-service-discovery-netflix-eureka/

@EnableEurekaClient
@SpringBootApplication
public class EurekaServerClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServerClientApplication.class, args);
	}	
}



