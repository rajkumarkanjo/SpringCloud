package com.eurekaclient.EurekaServerClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import java.util.TreeSet;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentServiceController {

	private static Map<String, List<Student>> schooDB = new HashMap<String, List<Student>>();

	  static{
		  
              schooDB = new HashMap<String, List<Student>>();
              
              List<Student> list = new ArrayList<Student>();
              
              Student std = new Student("RAJ", "Software Engineer");
              Student std1 = new Student("Spu", "DevOPS Engineer");
              
              list.add(std);
              list.add(std1);
              
              schooDB.put("mySchool", list); // we can fetch by key
              
              list = new ArrayList<Student>();
              
              Student std2 = new Student("Priya ", "Class V6");
              Student std3 = new Student("Sangavi", "Class V8");
              
              list.add(std2);
              list.add(std3);
              
              schooDB.put("myNewSchool", list); // we can fetch by key
              	  
	  } 
	  
	 // @RequestMapping(value = "/getStudents{schoolname}" , method = RequestMethod.GET)
	  @RequestMapping(value = "/getStudentDetailsForSchool/{schoolname}", method = RequestMethod.GET)
	  public List<Student> getStudents(@PathVariable String schoolname)
	  {
		  
		  System.out.println("Getting Student details for " + schoolname);
		  List<Student> stuList = schooDB.get(schoolname);
		 
		  
		  if(stuList==null)
		  {
			  stuList = new ArrayList<Student>();
			  Student stu = new Student("Not Found", "N/A");
			  stuList.add(stu);
			 	  
		  }
		  return stuList;
		 		  
		  
	  }
	  
	  
	  
	  
	
}
